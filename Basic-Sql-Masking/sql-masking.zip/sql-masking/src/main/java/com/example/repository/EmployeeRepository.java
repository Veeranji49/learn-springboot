package com.example.repository;

import com.example.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    @Query(value = """
        SELECT e.employee_id, e.name, d.department_name, 
               CASE 
                   WHEN :authorizedUser = 'admin' THEN e.phone_number
                   ELSE 'XXX-XXX-XXXX'
               END AS masked_phone_number, 
               e.salary
        FROM employees e
        JOIN departments d ON e.department_id = d.department_id
        WHERE e.salary > (
            SELECT AVG(salary)
            FROM employees
            WHERE department_id = e.department_id
        )
        ORDER BY e.salary DESC
        """, nativeQuery = true)
    List<Object[]> findEmployeesWithMaskedPhoneNumber(@Param("authorizedUser") String authorizedUser);
}