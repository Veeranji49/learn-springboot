package com.example;

import com.example.dto.EmployeeDTO;
import com.example.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class SqlMaskingApplication {
	public static void main(String[] args) {
		SpringApplication.run(SqlMaskingApplication.class, args);
	}

	@Bean
	public CommandLineRunner run(EmployeeService employeeService) {
		return args -> {
			String authorizedUser = "admin"; // Replace with actual user handling logic

			List<EmployeeDTO> employeeDTOs = employeeService.getEmployeesWithMaskedPhoneNumber(authorizedUser);

			// Print results for demonstration
			employeeDTOs.forEach(System.out::println);
		};
	}
}