package com.example.service;

import com.example.dto.EmployeeDTO;
import com.example.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<EmployeeDTO> getEmployeesWithMaskedPhoneNumber(String authorizedUser) {
        List<Object[]> results = employeeRepository.findEmployeesWithMaskedPhoneNumber(authorizedUser);
        List<EmployeeDTO> employeeDTOs = new ArrayList<>();

        for (Object[] result : results) {
            EmployeeDTO dto = new EmployeeDTO();
            dto.setEmployeeId((Integer) result[0]);
            dto.setName((String) result[1]);
            dto.setDepartmentName((String) result[2]);
            dto.setMaskedPhoneNumber((String) result[3]);
            dto.setSalary((Double) result[4]);
            employeeDTOs.add(dto);
        }

        return employeeDTOs;
    }
}